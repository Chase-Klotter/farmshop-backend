module.exports = {
  host: '0.0.0.0',
  port: process.env.PORT || 1337
};